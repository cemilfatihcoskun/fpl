-- Minimal, opinionated Neovim base config
vim.g.mapleader = " "
vim.g.maplocalleader = " "

local opt = vim.opt
opt.number = true
--opt.relativenumber = true
opt.cursorline = true
-- Syntax and terminal color highlighting are intentionally disabled.
--opt.termguicolors = true
opt.signcolumn = "yes"
opt.mouse = "a"
opt.clipboard = "unnamedplus" opt.wrap = false
opt.scrolloff = 8
opt.sidescrolloff = 8
opt.splitright = true
opt.splitbelow = true
opt.ignorecase = true
opt.smartcase = true
opt.incsearch = true
opt.hlsearch = false
opt.expandtab = true
opt.tabstop = 4
opt.softtabstop = 4
opt.shiftwidth = 4
opt.shiftround = true
opt.autoindent = true
opt.smartindent = true
opt.undofile = true
opt.updatetime = 250
opt.timeoutlen = 400
opt.completeopt = { "menu", "menuone", "noselect" }
opt.autocomplete = true
opt.autocompletedelay = 0
opt.laststatus = 3
opt.wrap = true          -- Enable line wrapping
opt.linebreak = true     -- Wrap lines at convenient words
opt.breakindent = true   -- Match indentation of the wrapped line

opt.mouse = "a"

-- 1. FARE AYARI: Seçimi bozmadan sadece '*' (Middle-click) panosuna kopyalar ve seçimi ekranda tutar
vim.keymap.set("v", "<LeftRelease>", '"*y', { desc = "Ctrl+V panosuna kopyala", silent = true })
-- 2. KLAVYE AYARI: Ctrl+Shift+C basınca '+' (Ctrl+V) panosuna kopyalar
vim.keymap.set("v", "<C-S-c>", '"+y', { desc = "Ctrl+V panosuna kopyala", silent = true })


vim.api.nvim_create_autocmd("FileType", {
    pattern = { "lua", "python", "javascript", "typescript", "json", "yaml", "html", "css", "sh", "bash", "cpp", "rust", "go" },
    callback = function()
        vim.opt_local.expandtab = true
        vim.opt_local.tabstop = 4
        vim.opt_local.softtabstop = 4
        vim.opt_local.shiftwidth = 4
    end,
})

vim.api.nvim_create_autocmd("FileType", {
    pattern = { "c", "h", "cpp", "hpp" },
    callback = function()
        vim.opt_local.expandtab = true
        vim.opt_local.tabstop = 4
        vim.opt_local.softtabstop = 4
        vim.opt_local.shiftwidth = 4
    end,
})

vim.api.nvim_create_autocmd("FileType", {
  pattern = "make",
  callback = function()
    vim.opt_local.expandtab = false
    vim.opt_local.shiftwidth = 8
    vim.opt_local.softtabstop = 0
  end,
})

--vim.cmd("syntax off")

vim.keymap.set("n", "<leader>w", "<cmd>write<cr>", { desc = "Kaydet" })
vim.keymap.set("n", "<leader>q", "<cmd>quit<cr>", { desc = "Çık" })
vim.keymap.set("n", "<leader>x", "<cmd>close<cr>", { desc = "Pencereyi kapat" })
vim.keymap.set("n", "<leader>h", "<cmd>nohlsearch<cr>", { desc = "Arama vurgusunu kapat" })
vim.keymap.set("n", "<Esc>", "<cmd>nohlsearch<cr><Esc>", { silent = true })

vim.api.nvim_create_autocmd("FileType", {
  pattern = "qf",
  callback = function(ev)
    vim.keymap.set("n", "q", "<cmd>cclose<cr>", {
      buffer = ev.buf,
      silent = true,
      desc = "Quickfix'i kapat",
    })
  end,
})

local function run_make(silent)
  vim.cmd("write")
  local root = vim.fs.root(0, { "Makefile" }) or vim.fn.getcwd()
  vim.cmd("lcd " .. vim.fn.fnameescape(root))
  vim.cmd("cclose")
  local make_args = ""
  if vim.fn.filereadable(root .. "/Makefile") == 0
      and vim.fn.filereadable(root .. "/build/Makefile") == 1 then
    make_args = "-C build"
  end
  local make_command = "make " .. make_args
  if silent then
    make_command = "silent " .. make_command
  end
  vim.cmd(make_command)
  local exit_code = vim.v.shell_error
  if exit_code ~= 0 then
    vim.cmd("copen")
  end
end

vim.keymap.set("n", "<leader>r", function()
  run_make(true)
end, { desc = "Sessiz make çalıştır" })

vim.keymap.set("n", "<F6>", function()
  run_make(false)
end, { desc = "Make çalıştır" })



local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not vim.loop.fs_stat(lazypath) then
  vim.fn.system({
    "git", "clone", "--filter=blob:none",
    "https://github.com/folke/lazy.nvim.git",
    "--branch=stable", lazypath,
  })
end
vim.opt.rtp:prepend(lazypath)

-- [Buraya senin yukarıdaki option, keymap ve ayarların gelecek]
-- ...

-- En alta da plugin yönetimini koyarsın:
require("lazy").setup({
  {
    'nvim-telescope/telescope.nvim',
    tag = '0.1.8',
    dependencies = { 'nvim-lua/plenary.nvim' },
    config = function()
      local builtin = require('telescope.builtin')
      vim.keymap.set('n', '<leader>ff', builtin.find_files, { desc = 'Dosyalarda Ara' })
      vim.keymap.set('n', '<leader>fg', builtin.live_grep, { desc = 'Metin İçinde Ara (Grep)' })
      vim.keymap.set('n', '<leader>fb', builtin.buffers, { desc = 'Açık Bufferlar' })
      vim.keymap.set('n', '<leader>fh', builtin.help_tags, { desc = 'Yardım Etiketleri' })
    end
  },
  {
    "nvim-tree/nvim-tree.lua",
    version = "*",
    lazy = false,
    dependencies = { "nvim-tree/nvim-web-devicons" }, -- İkonlar için (istersen silebilirsin)
    config = function()
        require("nvim-tree").setup {}
        vim.keymap.set('n', '<leader>e', '<cmd>NvimTreeToggle<cr>', { desc = 'Dosya Ağacını Aç/Kapat' })
    end,
    },
    {
      "nvim-mini/mini.pairs",
      event = "InsertEnter",
      opts = {},
    },
    {
    'akinsho/bufferline.nvim',
    version = "*",
    dependencies = 'nvim-tree/nvim-web-devicons',
    config = function()
      require("bufferline").setup({
        options = {
          mode = "buffers", -- "tabs" yerine buffer tabanlı çalışma
          separator_style = "thin", -- Sekme kenar şekli ("slant", "thick", "thin")
          always_show_bufferline = false,
          show_buffer_close_icons = false,
          show_close_icon = false,
          show_icon = false,
        }
      })

      -- Kısa yollar: Sekmeler arası hızlı geçiş için
      vim.keymap.set('n', '<S-l>', '<cmd>BufferLineCycleNext<cr>', { desc = 'Sonraki sekme' })
      vim.keymap.set('n', '<S-h>', '<cmd>BufferLineCyclePrev<cr>', { desc = 'Önceki sekme' })
      vim.keymap.set('n', '<leader>x', '<cmd>bdelete<cr>', { desc = 'Bufferı (sekmeden) kapat' })
    end
  },
})

-- C/C++ language server and native completion
vim.lsp.config("clangd", {
  cmd = { "clangd", "--background-index", "--clang-tidy" },
  filetypes = { "c", "cpp", "objc", "objcpp" },
  root_markers = { "compile_commands.json", ".clangd", ".git" },
})

vim.lsp.enable("clangd")

vim.keymap.set("i", "<C-j>", function()
  if vim.fn.pumvisible() == 1 then
    return "<C-n>"
  end
  return "<C-j>"
end, { expr = true, noremap = true, desc = "Completion aşağı" })

vim.keymap.set("i", "<C-k>", function()
  if vim.fn.pumvisible() == 1 then
    return "<C-p>"
  end
  return "<C-k>"
end, { expr = true, noremap = true, desc = "Completion yukarı" })

vim.keymap.set("i", "<C-Space>", function()
  vim.lsp.completion.get()
end, { desc = "LSP completion" })

vim.keymap.set("i", "<Tab>", function()
  if vim.fn.pumvisible() == 1 then
    local info = vim.fn.complete_info()
    if info.selected == -1 then
      return "<C-n><C-y>"
    end
    return "<C-y>"
  end
  return "<Tab>"
end, { expr = true, noremap = true, desc = "Completion kabul et" })

vim.api.nvim_create_autocmd("LspAttach", {
  callback = function(ev)
    local client = vim.lsp.get_client_by_id(ev.data.client_id)

    if client and client:supports_method("textDocument/completion") then
      local trigger_chars = {}
      for i = 32, 126 do
        trigger_chars[#trigger_chars + 1] = string.char(i)
      end
      client.server_capabilities.completionProvider.triggerCharacters = trigger_chars

      vim.lsp.completion.enable(true, client.id, ev.buf, { autotrigger = true })
    end

    local map = function(key, command, description)
      vim.keymap.set("n", key, command, { buffer = ev.buf, desc = description })
    end

    map("gd", vim.lsp.buf.definition, "Tanıma git")
    map("K", vim.lsp.buf.hover, "Bilgi göster")
    map("<leader>rn", vim.lsp.buf.rename, "Yeniden adlandır")
    map("<leader>ca", vim.lsp.buf.code_action, "Kod aksiyonu")
  end,
})

local function apply_theme()
    local state_file = os.getenv("HOME") .. "/.config/cfct/cfct_theme"
    local f = io.open(state_file, "r")
    local theme = "light"
    if f then
        theme = f:read("*all"):gsub("%s+", "")
        f:close()
    end

    if theme == "dark" then
        opt.background = "dark"
        vim.cmd("colorscheme default")
        vim.api.nvim_set_hl(0, "Normal", { bg = "#000000", fg = "#ffffff" })
        vim.api.nvim_set_hl(0, "NormalNC", { bg = "#000000", fg = "#ffffff" })
        vim.api.nvim_set_hl(0, "SignColumn", { bg = "#000000" })
        vim.api.nvim_set_hl(0, "LineNr", { bg = "#000000", fg = "#888888" })
        vim.api.nvim_set_hl(0, "CursorLine", { bg = "#111111" })
        vim.api.nvim_set_hl(0, "CursorLineNr", { bg = "#111111", fg = "#ffffff", bold = true })
    else
        opt.background = "light"
        vim.cmd("colorscheme default")
        vim.api.nvim_set_hl(0, "Normal", { bg = "#ffffff", fg = "#000000" })
        vim.api.nvim_set_hl(0, "NormalNC", { bg = "#ffffff", fg = "#000000" })
        vim.api.nvim_set_hl(0, "SignColumn", { bg = "#ffffff" })
        vim.api.nvim_set_hl(0, "LineNr", { bg = "#ffffff", fg = "#555555" })
        vim.api.nvim_set_hl(0, "CursorLine", { bg = "#f0f0f0" })
        vim.api.nvim_set_hl(0, "CursorLineNr", { bg = "#f0f0f0", fg = "#000000", bold = true })
    end
end

-- 2. `:ChangeTheme` komutu tanımla
vim.api.nvim_create_user_command("ChangeTheme", apply_theme, {})

-- İlk açılışta da uygula
apply_theme()

